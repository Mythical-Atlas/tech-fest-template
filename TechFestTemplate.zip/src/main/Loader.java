// TechFest 2019 Template
// Programmed by Ben Correll (from Mr. Storm's template)
// Last Updated 11-20-2019

package main;

import java.io.*;
import java.util.Scanner;

import functions.IO;
import functions.Parser;

class TechFest{
	public static void main(String[] args) throws IOException {
		int[][] in = Parser.getIntegersNoChars(IO.loadFileToString("inout/input.txt"), ' ', '\n');
		
		for(int i1 = 0; i1 < in.length; i1++) {
			for(int i2 = 0; i2 < in[i1].length; i2++) {
				System.out.println(in[i1][i2]);
			}
		}
	}
}